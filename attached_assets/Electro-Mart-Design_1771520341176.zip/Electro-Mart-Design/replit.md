# ElectroMart - E-Commerce Platform

## Overview

ElectroMart is a full-stack e-commerce web application for electronics, targeting the Algerian market. It features a product catalog, shopping cart, checkout with cash-on-delivery payment, wishlist functionality, an admin panel for product management, and user authentication via Replit Auth. The app uses a red-themed (#FF4D4D) design with the Poppins font family.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, bundled by Vite
- **Routing**: Wouter (lightweight client-side router)
- **State Management**: 
  - Zustand with persist middleware for cart and wishlist (stored in localStorage)
  - TanStack React Query for server state (API data fetching/caching)
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming, custom color system with HSL values
- **Animations**: Framer Motion for page transitions and scroll reveals
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers
- **Path aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend Architecture
- **Framework**: Express.js running on Node.js with TypeScript (tsx for dev, esbuild for production)
- **API Pattern**: RESTful JSON API under `/api/` prefix, with route definitions shared between client and server in `shared/routes.ts`
- **Authentication**: Replit Auth via OpenID Connect (passport.js with OIDC strategy), session-based with PostgreSQL session store
- **Server Entry**: `server/index.ts` creates HTTP server, registers routes, sets up Vite dev middleware or serves static files in production

### Data Storage
- **Database**: PostgreSQL (required, connection via `DATABASE_URL` environment variable)
- **ORM**: Drizzle ORM with `drizzle-zod` for schema-to-validation integration
- **Schema Location**: `shared/schema.ts` (main tables) and `shared/models/auth.ts` (auth tables)
- **Tables**: products, categories, orders, order_items, reviews, faqs, banners, users, sessions
- **Migrations**: Drizzle Kit with `db:push` command for schema synchronization

### Shared Code (`shared/` directory)
- `schema.ts` - Drizzle table definitions and Zod insert schemas for all domain entities
- `routes.ts` - API route definitions with paths, methods, input/output Zod schemas (acts as a type-safe API contract)
- `models/auth.ts` - User and session table definitions required by Replit Auth

### Build System
- **Development**: Vite dev server with HMR proxied through Express
- **Production Build**: `script/build.ts` runs Vite build for client and esbuild for server, outputs to `dist/` directory
- **Server bundling**: Selectively bundles server dependencies listed in an allowlist to reduce cold start times

### Key Design Decisions
1. **Shared route definitions**: The `shared/routes.ts` file defines API contracts (paths, methods, Zod schemas) used by both server handlers and client fetch hooks, ensuring type safety across the stack
2. **Storage interface pattern**: `server/storage.ts` defines an `IStorage` interface that abstracts database operations, making it possible to swap implementations
3. **Zustand for client state**: Cart and wishlist use Zustand with localStorage persistence rather than server-side storage, enabling guest shopping without authentication
4. **Replit Auth integration**: Authentication is handled through Replit's OIDC provider with mandatory users and sessions tables

## External Dependencies

### Required Services
- **PostgreSQL Database**: Must be provisioned and connected via `DATABASE_URL` environment variable
- **Replit Auth (OIDC)**: Requires `ISSUER_URL`, `REPL_ID`, and `SESSION_SECRET` environment variables

### Key npm Packages
- **Server**: express, drizzle-orm, pg, passport, openid-client, express-session, connect-pg-simple
- **Client**: react, wouter, @tanstack/react-query, zustand, framer-motion, react-hook-form, zod
- **UI**: Full shadcn/ui component library (Radix UI primitives, tailwind-merge, class-variance-authority, lucide-react icons)
- **Build**: vite, esbuild, tsx, drizzle-kit