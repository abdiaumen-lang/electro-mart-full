import { Heart, Eye, ShoppingCart, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/hooks/use-cart";
import { useWishlist } from "@/hooks/use-wishlist";
import { Link } from "wouter";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem, toggleCart } = useCart();
  const { toggleItem, isInWishlist } = useWishlist();
  
  const isWishlisted = isInWishlist(product.id);

  const discount = product.originalPrice 
    ? Math.round(((Number(product.originalPrice) - Number(product.price)) / Number(product.originalPrice)) * 100)
    : 0;

  const onAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addItem(product);
    toggleCart();
  };

  const onToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    toggleItem(product);
  };

  return (
    <div className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col h-full relative">
      {/* Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
        {discount > 0 && (
          <Badge className="bg-destructive text-white border-none shadow-sm px-2">
            -{discount}%
          </Badge>
        )}
        {product.isBestSeller && (
          <Badge className="bg-yellow-400 text-black border-none shadow-sm px-2">
            Best Seller
          </Badge>
        )}
      </div>

      {/* Image & Overlay */}
      <div className="relative aspect-square overflow-hidden bg-gray-50 p-4">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-contain mix-blend-multiply group-hover:scale-110 transition-transform duration-500"
        />
        
        {/* Hover Actions */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2 backdrop-blur-[1px]">
          <Button 
            size="icon" 
            variant="white" 
            className="rounded-full translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-0"
            onClick={onAddToCart}
          >
            <ShoppingCart className="w-5 h-5 text-gray-700" />
          </Button>
          <Link href={`/product/${product.id}`}>
            <Button 
              size="icon" 
              variant="white" 
              className="rounded-full translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75"
            >
              <Eye className="w-5 h-5 text-gray-700" />
            </Button>
          </Link>
          <Button 
            size="icon" 
            variant="white" 
            className={`rounded-full translate-y-4 group-hover:translate-y-0 transition-all duration-300 delay-150 ${isWishlisted ? 'bg-primary text-white hover:bg-primary/90' : ''}`}
            onClick={onToggleWishlist}
          >
            <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : 'text-gray-700'}`} />
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1">
        <div className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">{product.category}</div>
        <Link href={`/product/${product.id}`}>
          <h3 className="font-semibold text-gray-900 line-clamp-2 mb-2 hover:text-primary transition-colors cursor-pointer min-h-[40px]">
            {product.name}
          </h3>
        </Link>
        
        {/* Rating */}
        <div className="flex items-center gap-1 mb-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star 
              key={i} 
              className={`w-3.5 h-3.5 ${i < Math.round(Number(product.rating || 0)) ? 'fill-yellow-400 text-yellow-400' : 'fill-gray-200 text-gray-200'}`} 
            />
          ))}
          <span className="text-xs text-muted-foreground ml-1">({product.reviewCount})</span>
        </div>

        {/* Price */}
        <div className="mt-auto flex items-center justify-between">
          <div className="flex flex-col">
            {product.originalPrice && (
              <span className="text-xs text-muted-foreground line-through">
                {Number(product.originalPrice).toLocaleString()} DZD
              </span>
            )}
            <span className="font-bold text-lg text-primary">
              {Number(product.price).toLocaleString()} DZD
            </span>
          </div>
          
          <Button 
            size="sm" 
            className="rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 hidden sm:flex"
            onClick={onAddToCart}
          >
            Add
          </Button>
        </div>
      </div>
    </div>
  );
}
