import { Link, useLocation } from "wouter";
import { Search, ShoppingCart, Heart, User, Menu, Phone, Mail, ChevronDown, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { useWishlist } from "@/hooks/use-wishlist";
import { useLanguage, translations } from "@/hooks/use-language";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { CartDrawer } from "@/components/cart/CartDrawer";

export function Header() {
  const [location] = useLocation();
  const { items, toggleCart, total } = useCart();
  const { user, isAuthenticated, logout } = useAuth();
  const { items: wishlistItems } = useWishlist();
  const { language, setLanguage } = useLanguage();
  const t = translations[language].nav;
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const cartCount = items.reduce((acc, item) => acc + item.quantity, 0);
  const wishlistCount = wishlistItems.length;

  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    window.location.href = `/?search=${encodeURIComponent(searchQuery)}`;
  };

  return (
    <div className="w-full flex flex-col z-50">
      {/* Top Bar */}
      <div className="bg-[#f5f5f5] text-xs py-2 hidden md:block border-b border-gray-200">
        <div className="container-width flex justify-between items-center text-muted-foreground">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-2">
              <Phone className="w-3 h-3" /> +213 555 123 456
            </span>
            <span className="flex items-center gap-2">
              <Mail className="w-3 h-3" /> support@electromart.dz
            </span>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <span className="flex items-center gap-1 cursor-pointer hover:text-primary transition-colors">
                    <Globe className="w-3 h-3" /> {language === 'fr' ? 'Français' : 'English'}
                  </span>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-32">
                  <DropdownMenuItem onClick={() => setLanguage('fr')}>Français</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLanguage('en')}>English</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <span className="cursor-pointer hover:text-primary transition-colors">Currency: DZD</span>
              {isAuthenticated && (
                <Link href="/admin" className="text-primary font-bold hover:underline">{t.admin}</Link>
              )}
            </div>
            <div className="h-3 w-[1px] bg-gray-300"></div>
            {isAuthenticated ? (
               <div className="flex items-center gap-2">
                 <span>{user?.firstName || 'User'}</span>
                 <button onClick={() => logout()} className="text-primary hover:underline">{t.logout}</button>
               </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/login" className="hover:text-primary transition-colors">{t.login}</Link>
                <span>/</span>
                <Link href="/register" className="hover:text-primary transition-colors">{t.register}</Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="sticky top-0 bg-white shadow-sm z-40 py-4 transition-all duration-300">
        <div className="container-width flex items-center justify-between gap-8">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer group">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-primary/20 group-hover:scale-110 transition-transform duration-300">
                E
              </div>
              <span className="text-2xl font-bold tracking-tight text-foreground">
                Electro<span className="text-primary">Mart</span>
              </span>
            </div>
          </Link>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-xl relative">
            <form onSubmit={handleSearch} className={`flex w-full items-center border-2 rounded-full overflow-hidden transition-all duration-300 ${isSearchFocused ? 'border-primary ring-4 ring-primary/10' : 'border-gray-100 bg-gray-50'}`}>
              <Input 
                placeholder={t.searchPlaceholder} 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="border-none shadow-none focus-visible:ring-0 bg-transparent h-12 px-6"
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
              />
              <Button type="submit" size="icon" className="h-10 w-10 mr-1 rounded-full bg-primary hover:bg-primary/90">
                <Search className="w-5 h-5" />
              </Button>
            </form>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 sm:gap-4">
            <div className="hidden sm:flex items-center gap-1 cursor-pointer hover:text-primary transition-colors">
              <Button variant="ghost" size="icon" className="rounded-full">
                <User className="w-5 h-5" />
              </Button>
            </div>
            
            <div className="hidden sm:flex items-center gap-1 cursor-pointer hover:text-primary transition-colors">
              <Button variant="ghost" size="icon" className="rounded-full relative">
                <Heart className={`w-5 h-5 ${wishlistCount > 0 ? 'fill-primary text-primary' : ''}`} />
                {wishlistCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 rounded-full bg-primary text-white text-[10px]">
                    {wishlistCount}
                  </Badge>
                )}
              </Button>
            </div>

            <Button 
              variant="ghost" 
              className="relative flex items-center gap-3 px-2 sm:px-4 hover:bg-gray-50 rounded-full group"
              onClick={toggleCart}
            >
              <div className="relative">
                <ShoppingCart className="w-6 h-6 text-foreground group-hover:text-primary transition-colors" />
                {cartCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 rounded-full bg-primary text-white border-2 border-white">
                    {cartCount}
                  </Badge>
                )}
              </div>
              <div className="hidden lg:flex flex-col items-start text-xs">
                <span className="text-muted-foreground">{t.total}</span>
                <span className="font-bold text-sm">{total().toLocaleString()} DZD</span>
              </div>
            </Button>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-8 mt-8">
                  <nav className="flex flex-col gap-4">
                    <Link href="/" className="text-lg font-medium hover:text-primary">{t.home}</Link>
                    <Link href="/category/smartphones" className="text-lg font-medium hover:text-primary">{t.smartphones}</Link>
                    <Link href="/category/laptops" className="text-lg font-medium hover:text-primary">{t.laptops}</Link>
                    <Link href="/category/televisions" className="text-lg font-medium hover:text-primary">{t.televisions}</Link>
                  </nav>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Navigation Menu - Desktop */}
      <div className="hidden md:block bg-white border-b border-gray-100 shadow-sm relative z-30">
        <div className="container-width">
          <nav className="flex items-center gap-8 h-14">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="font-semibold gap-2 px-0 hover:bg-transparent hover:text-primary">
                  <Menu className="w-5 h-5" />
                  {t.allCategories}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="start">
                <DropdownMenuItem className="cursor-pointer">{t.smartphones}</DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">{t.laptops}</DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">{t.televisions}</DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">Cameras & Audio</DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">Gaming Consoles</DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">{t.accessories}</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <div className="h-6 w-[1px] bg-gray-200"></div>

            <div className="flex items-center gap-8 text-sm font-medium">
              <Link href="/category/smartphones" className="hover:text-primary transition-colors">{t.smartphones}</Link>
              <Link href="/category/laptops" className="hover:text-primary transition-colors">{t.laptops}</Link>
              <Link href="/category/televisions" className="hover:text-primary transition-colors">{t.televisions}</Link>
              <Link href="/category/accessories" className="hover:text-primary transition-colors">{t.accessories}</Link>
              <Link href="/contact" className="hover:text-primary transition-colors">{t.contact}</Link>
            </div>
            
            <div className="ml-auto text-primary font-medium text-sm animate-pulse">
              {language === 'fr' ? 'Utilisez le code "ELECTRO30" pour 30% de réduction!' : 'Use code "ELECTRO30" for 30% off!'}
            </div>
          </nav>
        </div>
      </div>
      
      <CartDrawer />
    </div>
  );
}

