import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type CreateOrderRequest } from "@shared/routes";

export function useCreateOrder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreateOrderRequest) => {
      const res = await fetch(api.orders.create.path, {
        method: api.orders.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create order");
      }
      return api.orders.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      // Invalidate orders if we had an orders list, but mostly just used for confirmation
      // Could invalidate user profile if we had one showing past orders
    },
  });
}
