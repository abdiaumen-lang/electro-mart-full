import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Language = 'fr' | 'en';

interface LanguageState {
  language: Language;
  setLanguage: (lang: Language) => void;
}

export const useLanguage = create<LanguageState>()(
  persist(
    (set) => ({
      language: 'fr',
      setLanguage: (lang) => set({ language: lang }),
    }),
    {
      name: 'electromart-language',
    }
  )
);

export const translations = {
  fr: {
    nav: {
      home: 'Accueil',
      smartphones: 'Smartphones',
      laptops: 'Ordinateurs',
      televisions: 'Téléviseurs',
      accessories: 'Accessoires',
      contact: 'Contact',
      admin: 'Panneau Admin',
      login: 'Connexion',
      register: 'Inscription',
      logout: 'Déconnexion',
      searchPlaceholder: 'Rechercher des produits...',
      total: 'Total',
      allCategories: 'Toutes les catégories',
    },
    hero: {
      newArrivals: 'Nouveautés 2026',
      titlePrefix: 'Technologie',
      titleSuffix: 'Suivante',
      desc: 'Découvrez le futur de l\'électronique. Qualité premium, prix imbattables et livraison ultra-rapide partout en Algérie.',
      shopNow: 'Acheter Maintenant',
      catalog: 'Catalogue',
      customers: 'Clients',
      original: 'Original',
    },
    home: {
      featuredTitle: 'Tech de Sélection',
      featuredSubtitle: 'Sélection Premium',
      bestSellers: 'Meilleures Ventes',
      trust: {
        shipping: 'Livraison Gratuite',
        shippingDesc: 'Sur toutes les commandes > 10k DZD',
        secure: 'Paiement Sécurisé',
        secureDesc: 'Paiement 100% sécurisé',
        cod: 'Paiement à la Livraison',
        codDesc: 'Payez à la réception',
        support: 'Support 24/7',
        supportDesc: 'Support dédié',
      },
      faq: 'Questions Fréquemment Posées',
      searchResult: 'Résultats pour',
      noMatches: 'Aucun match trouvé',
    }
  },
  en: {
    nav: {
      home: 'Home',
      smartphones: 'Smartphones',
      laptops: 'Laptops',
      televisions: 'Televisions',
      accessories: 'Accessories',
      contact: 'Contact',
      admin: 'Admin Panel',
      login: 'Login',
      register: 'Register',
      logout: 'Logout',
      searchPlaceholder: 'Search for products...',
      total: 'Total',
      allCategories: 'All Categories',
    },
    hero: {
      newArrivals: 'New Arrivals 2026',
      titlePrefix: 'Next Gen',
      titleSuffix: 'Technology',
      desc: 'Experience the future of electronics. Premium quality, unbeatable prices, and lightning-fast delivery across Algeria.',
      shopNow: 'Shop Now',
      catalog: 'View Catalog',
      customers: 'Customers',
      original: 'Original',
    },
    home: {
      featuredTitle: 'Featured Tech',
      featuredSubtitle: 'Premium Selection',
      bestSellers: 'Best Selling Products',
      trust: {
        shipping: 'Free Shipping',
        shippingDesc: 'On all orders over 10k DZD',
        secure: 'Secure Payment',
        secureDesc: '100% secure payment',
        cod: 'Cash On Delivery',
        codDesc: 'Pay when you receive',
        support: '24/7 Support',
        supportDesc: 'Dedicated support',
      },
      faq: 'Frequently Asked Questions',
      searchResult: 'Search results for',
      noMatches: 'No matches found',
    }
  }
};
