import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/products/ProductCard";
import { useProducts } from "@/hooks/use-products";
import { useLocation, Link } from "wouter";
import { useLanguage, translations } from "@/hooks/use-language";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Truck, Shield, Headphones, RefreshCw, ArrowRight, Timer, SearchX } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const search = searchParams.get("search") || undefined;
  const { language } = useLanguage();
  const t = translations[language].home;
  const h = translations[language].hero;

  const { data: featuredProducts } = useProducts({ featured: true, limit: 8, search });
  const { data: bestSellers } = useProducts({ bestSeller: true, limit: 6 });

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      {/* Search Results info */}
      {search && (
        <div className="bg-primary/5 py-6 border-b border-primary/10">
          <div className="container-width">
            <h2 className="text-xl font-medium">{t.searchResult}: <span className="font-bold">"{search}"</span></h2>
          </div>
        </div>
      )}

      {/* Hero Section - Hide if searching */}
      {!search && (
        <section className="relative h-[600px] md:h-[800px] flex items-center overflow-hidden">
          {/* Background with Dark Wash */}
          <div className="absolute inset-0 z-0">
            <img 
              src="/images/hero-bg.png" 
              className="w-full h-full object-cover"
              alt="Hero Background"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent"></div>
          </div>

          <div className="container-width relative z-10 text-white">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="space-y-8"
              >
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/30 backdrop-blur-md">
                  <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                  <span className="text-primary font-bold tracking-wider uppercase text-xs">{h.newArrivals}</span>
                </div>
                
                <h1 className="text-5xl md:text-8xl font-bold leading-[1.1] tracking-tight">
                  {h.titlePrefix} <br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-red-400">{h.titleSuffix}</span>
                </h1>
                
                <p className="text-gray-300 text-lg md:text-xl max-w-lg leading-relaxed">
                  {h.desc}
                </p>
                
                <div className="flex flex-wrap gap-4 pt-4">
                  <Button size="lg" className="rounded-full px-10 text-lg h-16 shadow-xl shadow-primary/20 hover-elevate">
                    {h.shopNow} <ArrowRight className="ml-2 w-6 h-6" />
                  </Button>
                  <Button size="lg" variant="outline" className="rounded-full px-10 text-lg h-16 bg-white/5 backdrop-blur-md border-white/20 hover:bg-white/10 text-white hover-elevate">
                    {h.catalog}
                  </Button>
                </div>

                <div className="flex items-center gap-8 pt-8 border-t border-white/10">
                  <div className="flex flex-col">
                    <span className="text-3xl font-bold">50k+</span>
                    <span className="text-xs text-gray-400 uppercase tracking-widest">{h.customers}</span>
                  </div>
                  <div className="w-[1px] h-10 bg-white/10"></div>
                  <div className="flex flex-col">
                    <span className="text-3xl font-bold">100%</span>
                    <span className="text-xs text-gray-400 uppercase tracking-widest">{h.original}</span>
                  </div>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
                animate={{ opacity: 1, scale: 1, rotate: 0 }}
                transition={{ duration: 1, delay: 0.2 }}
                className="relative hidden md:block"
              >
                <div className="relative group">
                  <div className="absolute inset-0 bg-primary/20 rounded-full blur-[120px] group-hover:bg-primary/30 transition-colors duration-700"></div>
                  <img 
                    src="/images/iphone15.png" 
                    alt="Featured Product" 
                    className="w-full object-contain drop-shadow-[0_35px_35px_rgba(0,0,0,0.5)] animate-float relative z-10"
                  />
                  
                  {/* Floating Price Tag */}
                  <div className="absolute bottom-10 -left-10 bg-white/10 backdrop-blur-xl p-6 rounded-3xl border border-white/20 shadow-2xl animate-pulse-slow z-20">
                    <p className="text-xs text-primary font-bold uppercase mb-1">Limited Offer</p>
                    <p className="text-3xl font-bold">210,000 <span className="text-sm font-normal">DZD</span></p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
          
          {/* Scroll Indicator */}
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50">
            <div className="w-[2px] h-12 bg-gradient-to-b from-primary to-transparent"></div>
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold">Scroll</span>
          </div>
        </section>
      )}

      {/* Trust Badges */}
      {!search && (
        <section className="py-10 bg-white border-b border-gray-100">
          <div className="container-width">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <TrustBadge icon={<Truck className="w-6 h-6" />} title={t.trust.shipping} desc={t.trust.shippingDesc} />
              <TrustBadge icon={<Shield className="w-6 h-6" />} title={t.trust.secure} desc={t.trust.secureDesc} />
              <TrustBadge icon={<RefreshCw className="w-6 h-6" />} title={t.trust.cod} desc={t.trust.codDesc} />
              <TrustBadge icon={<Headphones className="w-6 h-6" />} title={t.trust.support} desc={t.trust.supportDesc} />
            </div>
          </div>
        </section>
      )}

      {/* Featured Products */}
      <section className="py-24 bg-white relative overflow-hidden">
        {/* Abstract background shape */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
        
        <div className="container-width relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-16">
            <div className="max-w-xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <span className="text-primary font-bold uppercase tracking-[0.2em] text-xs mb-4 block">{t.featuredSubtitle}</span>
                <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                  {search ? (
                    <>{t.searchResult} <span className="text-primary">"{search}"</span></>
                  ) : (
                    <>{t.featuredTitle.split(' ')[0]} <span className="text-primary">{t.featuredTitle.split(' ')[1]}</span></>
                  )}
                </h2>
                <div className="w-20 h-1.5 bg-primary rounded-full"></div>
              </motion.div>
            </div>
            {!search && (
              <Link href="/shop">
                <Button variant="ghost" className="group text-primary font-bold hover:bg-primary/5 rounded-xl h-12 px-6">
                  {language === 'fr' ? 'Explorer tout le catalogue' : 'Explore Full Catalog'} 
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            )}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-10">
            {featuredProducts ? (
              featuredProducts.length > 0 ? (
                featuredProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <ProductCard product={product} />
                  </motion.div>
                ))
              ) : (
                <div className="col-span-full py-32 text-center bg-gray-50 rounded-[3rem] border-2 border-dashed border-gray-200">
                  <SearchX className="w-20 h-20 text-gray-300 mx-auto mb-6" />
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{t.noMatches}</h3>
                  <Button variant="default" onClick={() => window.location.href = '/'} className="rounded-full px-8">
                    {language === 'fr' ? 'Voir tous les produits' : 'View All Products'}
                  </Button>
                </div>
              )
            ) : (
              // Loading skeletons
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="bg-gray-100 rounded-[2rem] aspect-[3/4] animate-pulse"></div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Promo Banners - Hide if searching */}
      {!search && (
        <>
          <section className="py-10">
            <div className="container-width">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="relative h-64 rounded-3xl overflow-hidden group cursor-pointer">
                  <img src="https://pixabay.com/get/g8b5627e929e5340ae5fd99f9648ec19354a818278bb21ea920b6a6cd95231bb91252e8aeaea68d785a32ea1d2ff61a8e1c6d1b51caa5dd2529852d716ee63e97_1280.jpg" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="Promo" />
                  <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex flex-col justify-center p-8">
                    <span className="text-white/80 font-medium mb-2">{language === 'fr' ? 'Temps Limité' : 'Limited Time'}</span>
                    <h3 className="text-3xl font-bold text-white mb-4">{language === 'fr' ? 'Livraison Gratuite' : 'Free Shipping'}<br/>{language === 'fr' ? 'Partout' : 'Everywhere'}</h3>
                    <Button variant="white" className="w-fit rounded-full">{h.shopNow}</Button>
                  </div>
                </div>
                <div className="relative h-64 rounded-3xl overflow-hidden group cursor-pointer">
                  <img src="https://images.unsplash.com/photo-1600861194942-f883de0dfe96?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="Promo" />
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-transparent flex flex-col justify-center p-8">
                    <span className="text-white/90 font-medium mb-2">Black Friday</span>
                    <h3 className="text-3xl font-bold text-white mb-4">{language === 'fr' ? 'Vente de Déstockage' : 'Clearance Sale'}<br/>Up to 70% Off</h3>
                    <Button variant="secondary" className="w-fit rounded-full">{language === 'fr' ? 'Explorer les Offres' : 'Explore Deals'}</Button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Best Sellers */}
          <section className="py-20 bg-gray-50">
            <div className="container-width">
              <div className="text-center max-w-2xl mx-auto mb-16">
                <span className="text-primary font-bold uppercase tracking-wider text-sm mb-2 block">{language === 'fr' ? 'Mieux Notés' : 'Top Rated'}</span>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">{t.bestSellers}</h2>
                <p className="text-muted-foreground">{language === 'fr' ? 'Découvrez ce que tout le monde achète.' : 'Check out what everyone is buying right now.'}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {bestSellers ? (
                  bestSellers.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))
                ) : (
                  // Loading skeletons
                  Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="bg-white rounded-2xl aspect-[4/5] animate-pulse"></div>
                  ))
                )}
              </div>
            </div>
          </section>

          {/* FAQ Section */}
          <section className="py-20 bg-white">
            <div className="container-width max-w-4xl">
              <div className="text-center mb-16">
                <h2 className="text-3xl font-bold mb-4">{t.faq}</h2>
              </div>

              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1" className="border-b-0 mb-4 rounded-xl border px-6 hover:bg-gray-50 transition-colors">
                  <AccordionTrigger className="hover:no-underline font-medium py-6">{language === 'fr' ? 'Quels modes de paiement acceptez-vous ?' : 'What payment methods do you accept?'}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground pb-6">
                    {language === 'fr' 
                      ? 'Nous acceptons actuellement le paiement à la livraison (COD) pour toutes les commandes. Nous travaillons sur BaridiMob.'
                      : 'We currently accept Cash on Delivery (COD) for all orders. We are working on adding BaridiMob soon.'}
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </section>
        </>
      )}

      <Footer />
    </div>
  );
}


function TrustBadge({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="flex flex-col items-center text-center p-6 rounded-2xl bg-white hover:bg-gray-50 hover:shadow-lg transition-all duration-300 group">
      <div className="w-14 h-14 bg-red-50 text-primary rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="font-bold text-gray-900 mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}

function CountdownUnit({ value, label }: { value: string, label: string }) {
  return (
    <div className="flex flex-col items-center">
      <div className="bg-gray-900 text-white w-14 h-14 rounded-lg flex items-center justify-center text-xl font-bold mb-2 shadow-lg">
        {value}
      </div>
      <span className="text-xs uppercase font-medium tracking-wide text-gray-500">{label}</span>
    </div>
  );
}
