## Packages
framer-motion | Complex animations for hero slider, scroll reveals, and cart drawer
react-intersection-observer | For scroll-triggered animations
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ['Poppins', 'sans-serif'],
  display: ['Poppins', 'sans-serif'],
}
Images will be sourced from Unsplash for the demo.
The theme uses a primary red color (#FF4D4D).
