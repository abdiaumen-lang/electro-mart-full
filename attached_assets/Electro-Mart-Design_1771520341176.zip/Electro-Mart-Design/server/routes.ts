import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth Setup
  await setupAuth(app);
  registerAuthRoutes(app);

  // === Products ===
  app.get(api.products.list.path, async (req, res) => {
    const params = api.products.list.input?.parse(req.query);
    const products = await storage.getProducts(params);
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  });

  app.post(api.products.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const product = await storage.createProduct(req.body);
    res.status(201).json(product);
  });

  // === Categories ===
  app.get(api.categories.list.path, async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  // === Orders ===
  app.post(api.orders.create.path, async (req, res) => {
    const userId = req.user?.claims?.sub; // Optional: Attach user ID if logged in
    const order = await storage.createOrder({ ...req.body, userId });
    res.status(201).json(order);
  });

  app.get(api.orders.get.path, async (req, res) => {
    const order = await storage.getOrder(Number(req.params.id));
    if (!order) return res.status(404).json({ message: "Order not found" });
    res.json(order);
  });

  // === Reviews ===
  app.get(api.reviews.list.path, async (req, res) => {
    const reviews = await storage.getReviews(Number(req.params.id));
    res.json(reviews);
  });

  app.post(api.reviews.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const review = await storage.createReview(req.body);
    res.status(201).json(review);
  });

  // === FAQs ===
  app.get(api.faqs.list.path, async (req, res) => {
    const faqs = await storage.getFaqs();
    res.json(faqs);
  });

  // === Banners ===
  app.get(api.banners.list.path, async (req, res) => {
    const banners = await storage.getBanners();
    res.json(banners);
  });

  // SEED DATA
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const categories = await storage.getCategories();
  if (categories.length === 0) {
    console.log("Seeding database...");
    
    // 1. Categories
    await db.insert(schema.categories).values([
      { name: "Smartphones", slug: "smartphones", image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500" },
      { name: "Laptops", slug: "laptops", image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500" },
      { name: "Headphones", slug: "headphones", image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500" },
      { name: "Cameras", slug: "cameras", image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500" },
    ]);

    // 2. Products
    await db.insert(schema.products).values([
      {
        name: "Sony WH-1000XM5",
        description: "Industry-leading noise canceling headphones.",
        price: "45000.00",
        originalPrice: "55000.00",
        image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800",
        category: "headphones",
        isFeatured: true,
        isBestSeller: true,
        rating: "4.8",
        reviewCount: 124,
      },
      {
        name: "iPhone 15 Pro Max",
        description: "The ultimate iPhone with titanium design.",
        price: "250000.00",
        originalPrice: "280000.00",
        image: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800",
        category: "smartphones",
        isFeatured: true,
        isBestSeller: true,
        rating: "4.9",
        reviewCount: 89,
      },
      {
        name: "MacBook Air M2",
        description: "Supercharged by M2. Strikingly thin and fast.",
        price: "180000.00",
        originalPrice: "200000.00",
        image: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=800",
        category: "laptops",
        isFeatured: true,
        rating: "4.7",
        reviewCount: 56,
      },
      {
        name: "Canon EOS R5",
        description: "Professional mirrorless camera for pros.",
        price: "450000.00",
        image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800",
        category: "cameras",
        isFeatured: false,
        rating: "4.9",
        reviewCount: 12,
      },
      {
        name: "Samsung 65\" QLED 4K",
        description: "Stunning 4K resolution with quantum dot technology.",
        price: "120000.00",
        originalPrice: "145000.00",
        image: "https://images.unsplash.com/photo-1593784991095-a20506948430?w=800",
        category: "televisions",
        isFeatured: true,
        isOnSale: true,
        discountPercentage: 17,
        rating: "4.6",
        reviewCount: 45,
      }
    ]);

    // 3. FAQs
    await db.insert(schema.faqs).values([
      { question: "What are the payment methods?", answer: "We accept Cash on Delivery (COD) for all orders in Algeria." },
      { question: "How long does delivery take?", answer: "Delivery usually takes 2-5 business days depending on your wilaya." },
      { question: "Is there a warranty?", answer: "Yes, all electronic products come with a 1-year official warranty." },
    ]);

    // 4. Banners
    await db.insert(schema.banners).values([
      {
        title: "Spring Sale 50% Off",
        description: "Get the best deals on electronics this season.",
        image: "https://images.unsplash.com/photo-1498049389873-61111283a047?w=1200",
        type: "hero",
        active: true
      },
      {
        title: "Free Shipping",
        description: "On all orders over 50,000 DZD",
        image: "https://images.unsplash.com/photo-1580828343064-fde4fc206bc6?w=800",
        type: "promo",
        active: true
      }
    ]);
  }
}

import * as schema from "@shared/schema";
import { db } from "./db";
