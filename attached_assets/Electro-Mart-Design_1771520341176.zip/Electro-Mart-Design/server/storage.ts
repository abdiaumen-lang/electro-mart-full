import { db } from "./db";
import {
  products,
  categories,
  orders,
  orderItems,
  reviews,
  faqs,
  banners,
  insertProductSchema,
  insertOrderSchema,
  insertReviewSchema,
  type Product,
  type InsertProduct,
  type Category,
  type Order,
  type InsertOrder,
  type Review,
  type InsertReview,
  type Faq,
  type Banner,
  type CreateOrderRequest
} from "@shared/schema";
import { eq, desc, ilike, or, and, sql } from "drizzle-orm";
import { authStorage, type IAuthStorage } from "./replit_integrations/auth/storage";

export interface IStorage extends IAuthStorage {
  // Products
  getProducts(params?: { category?: string; search?: string; featured?: boolean; bestSeller?: boolean; limit?: number }): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  
  // Orders
  createOrder(order: CreateOrderRequest & { userId?: string }): Promise<Order>;
  getOrder(id: number): Promise<Order & { items: any[] } | undefined>;
  
  // Reviews
  getReviews(productId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  
  // FAQs
  getFaqs(): Promise<Faq[]>;
  
  // Banners
  getBanners(): Promise<Banner[]>;
}

export class DatabaseStorage extends authStorage.constructor implements IStorage {
  constructor() {
    super();
  }

  // Products
  async getProducts(params?: { category?: string; search?: string; featured?: boolean; bestSeller?: boolean; limit?: number }): Promise<Product[]> {
    let query = db.select().from(products);
    const conditions = [];

    if (params?.category) {
      conditions.push(ilike(products.category, params.category));
    }
    if (params?.search) {
      conditions.push(
        or(
          ilike(products.name, `%${params.search}%`),
          ilike(products.description, `%${params.search}%`)
        )
      );
    }
    if (params?.featured) {
      conditions.push(eq(products.isFeatured, true));
    }
    if (params?.bestSeller) {
      conditions.push(eq(products.isBestSeller, true));
    }

    if (conditions.length > 0) {
      // @ts-ignore
      query = query.where(and(...conditions));
    }

    if (params?.limit) {
      // @ts-ignore
      query = query.limit(params.limit);
    }

    return await query.orderBy(desc(products.id));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  // Orders
  async createOrder(req: CreateOrderRequest & { userId?: string }): Promise<Order> {
    // 1. Calculate total
    let total = 0;
    const itemsWithPrice = [];

    for (const item of req.items) {
      const product = await this.getProduct(item.productId);
      if (!product) throw new Error(`Product ${item.productId} not found`);
      const price = Number(product.price);
      total += price * item.quantity;
      itemsWithPrice.push({ ...item, price });
    }

    // 2. Create order
    const [order] = await db.insert(orders).values({
      userId: req.userId,
      guestInfo: req.guestInfo,
      total: total.toString(),
      status: "pending",
      paymentMethod: "cod"
    }).returning();

    // 3. Create order items
    for (const item of itemsWithPrice) {
      await db.insert(orderItems).values({
        orderId: order.id,
        productId: item.productId,
        quantity: item.quantity,
        price: item.price.toString()
      });
    }

    return order;
  }

  async getOrder(id: number): Promise<Order & { items: any[] } | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return undefined;

    const items = await db.select({
      id: orderItems.id,
      quantity: orderItems.quantity,
      price: orderItems.price,
      product: products
    })
    .from(orderItems)
    .where(eq(orderItems.orderId, id))
    .leftJoin(products, eq(orderItems.productId, products.id));

    return { ...order, items };
  }

  // Reviews
  async getReviews(productId: number): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.productId, productId)).orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    return newReview;
  }

  // FAQs
  async getFaqs(): Promise<Faq[]> {
    return await db.select().from(faqs);
  }

  // Banners
  async getBanners(): Promise<Banner[]> {
    return await db.select().from(banners).where(eq(banners.active, true));
  }
}

export const storage = new DatabaseStorage();
